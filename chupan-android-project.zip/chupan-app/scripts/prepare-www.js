// بازی را برای اپ آماده می‌کند: three.js را از node_modules داخل پروژه می‌گذارد تا بدون اینترنت اجرا شود.
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const www = path.join(root, 'www');
const src = path.join(root, 'src', 'shepherd_game.html');
const threeSrc = path.join(root, 'node_modules', 'three', 'build', 'three.min.js');

if (!fs.existsSync(threeSrc)) {
  console.error('three.js پیدا نشد. اول `npm install` را اجرا کنید.');
  process.exit(1);
}
fs.mkdirSync(www, { recursive: true });
let html = fs.readFileSync(src, 'utf8');
const cdn = /<script src="https:\/\/cdnjs\.cloudflare\.com\/ajax\/libs\/three\.js\/r128\/three\.min\.js"><\/script>/;
if (!cdn.test(html)) {
  console.error('تگ three.js در بازی پیدا نشد.');
  process.exit(1);
}
html = html.replace(cdn, '<script src="three.min.js"></script>');
fs.writeFileSync(path.join(www, 'index.html'), html);
fs.copyFileSync(threeSrc, path.join(www, 'three.min.js'));
console.log('www آماده شد (index.html + three.min.js)');
