# چوپان — اپلیکیشن اندروید

این پوشه پروژهٔ آمادهٔ ساخت فایل نصبی (APK) بازی است. بازی با Capacitor داخل یک اپ بومی اندروید بسته‌بندی می‌شود و three.js داخل خود اپ است، پس بدون اینترنت هم اجرا می‌شود. بازی خودکار ذخیره می‌شود و دکمهٔ «ادامهٔ بازی» دارد.

## راه ۱ — ساخت APK بدون نصب هیچ‌چیز (GitHub Actions)

۱. یک مخزن (repository) خالی در GitHub بسازید و محتوای همین پوشه را در آن آپلود کنید.
۲. به تب **Actions** بروید و workflow به نام **Build Android APK** را اجرا کنید (Run workflow). حدود ۵ تا ۸ دقیقه طول می‌کشد.
۳. بعد از پایان، از پایین صفحهٔ اجرا فایل **chupan-apk** را دانلود کنید. داخلش `app-debug.apk` است.
۴. فایل را به گوشی بفرستید و نصب کنید (باید «نصب از منبع ناشناس» را اجازه بدهید).

## راه ۲ — ساخت روی کامپیوتر خودتان

پیش‌نیاز: Node.js 18 یا بالاتر، JDK 17 و Android Studio (برای Android SDK).

```bash
npm install
npm run setup        # ساخت پروژهٔ اندروید، آیکون و تنظیمات
npm run apk          # در لینوکس و مک: npm run apk:unix
```

خروجی: `android/app/build/outputs/apk/debug/app-debug.apk`

برای باز کردن در Android Studio و اجرا روی گوشی یا شبیه‌ساز: `npm run open`

## بعد از تغییر در بازی

فایل `src/shepherd_game.html` را عوض کنید (یا بازی را با `build_game.py` دوباره بسازید و در `src/` بگذارید) و بعد:

```bash
npm run sync
npm run apk
```

## انتشار در فروشگاه

APK بالا از نوع debug است و فقط برای نصب مستقیم مناسب است. برای کافه‌بازار، مایکت یا گوگل‌پلی باید نسخهٔ release با کلید امضای خودتان ساخته شود:

1. در Android Studio از منوی **Build ← Generate Signed Bundle / APK** یک keystore بسازید و فایل AAB (برای گوگل‌پلی) یا APK بسازید.
2. keystore را حتماً نگه دارید؛ بدون آن نمی‌توانید بعداً بازی را به‌روزرسانی کنید.
3. شناسهٔ اپ در `capacitor.config.json` برابر `com.chupan.game` است؛ قبل از انتشار آن را به شناسهٔ منحصربه‌فرد خودتان عوض کنید.

## iOS

بسته‌بندی iOS هم با همین پروژه ممکن است (`npm i @capacitor/ios` و `npx cap add ios`)، ولی ساخت و نصب آن فقط روی مک با Xcode و حساب Apple Developer شدنی است.

## ساختار پوشه

- `src/shepherd_game.html`: خود بازی
- `assets/`: آیکون و صفحهٔ شروع (با پایتون ساخته شده‌اند)
- `scripts/`: آماده‌سازی فایل‌ها و تنظیمات اندروید
- `.github/workflows/android.yml`: ساخت خودکار APK
