#!/usr/bin/env python3
"""
چوپان — Shepherd game builder
--------------------------------
این اسکریپت پایتون:
  1) همهٔ مدل‌های سه‌بعدیِ مینیمال (low-poly) را از اشکال ساده می‌سازد؛
  2) چیدمان جهان (درخت، سنگ، حصار، مناطق خطرناک، ...) را با seed ثابت تولید می‌کند؛
  3) هر دو را به‌صورت JSON داخل template.html می‌گذارد و shepherd_game.html را می‌سازد.

اجرا:  python3 build_game.py
"""
import json
import math
import pathlib
import random

HERE = pathlib.Path(__file__).resolve().parent
OUT = HERE / "shepherd_game.html"

# ---------------------------------------------------------------- primitives
# هر قطعه یک dict است:  t=نوع, s=ابعاد, p=مرکز, c=رنگ
# n+pv = قطعهٔ متحرک (مثلاً پا) که حول نقطهٔ pv می‌چرخد، r = چرخش (رادیان)


def B(w, h, d, x, y, z, c, **k):
    return dict(t="box", s=[w, h, d], p=[x, y, z], c=c, **k)


def C(rt, rb, h, x, y, z, c, seg=8, **k):
    return dict(t="cyl", s=[rt, rb, h, seg], p=[x, y, z], c=c, **k)


def K(rad, h, x, y, z, c, seg=7, **k):
    return dict(t="cone", s=[rad, h, seg], p=[x, y, z], c=c, **k)


def S(rad, x, y, z, c, ws=7, hs=5, **k):
    return dict(t="sph", s=[rad, ws, hs], p=[x, y, z], c=c, **k)


def D(rad, x, y, z, c, **k):
    return dict(t="dod", s=[rad], p=[x, y, z], c=c, **k)


def limb(name, x, top, z, w, h, d, c):
    """پا یا دست: از نقطهٔ بالا آویزان و حول آن می‌چرخد."""
    return B(w, h, d, x, top - h / 2, z, c, n=name, pv=[x, top, z])


# ---------------------------------------------------------------- models
def lg(name, x, top, z, w, h, d, c, hoof=None, hh=0.12):
    """پا/دست با سُم یا چکمه (هر دو حول یک لولا می‌چرخند)."""
    parts = [limb(name, x, top, z, w, h, d, c)]
    if hoof:
        parts.append(B(w + 0.03, hh, d + 0.04, x, hh / 2, z + 0.02, hoof, n=name, pv=[x, top, z]))
    return parts


def human(tunic, pants, hat, skin="#e8b98a", band="#8a5a3c", vest="#6b4a2d", hair="#3b2a1c", beard=False):
    p = []
    p += lg("legL", -0.17, 0.8, 0, 0.28, 0.8, 0.3, pants, "#2b1d14", 0.24)
    p += lg("legR", 0.17, 0.8, 0, 0.28, 0.8, 0.3, pants, "#2b1d14", 0.24)
    p += [
        B(0.72, 0.82, 0.42, 0, 1.21, 0, tunic),
        B(0.76, 0.56, 0.46, 0, 1.3, 0, vest),
        B(0.1, 0.56, 0.47, 0, 1.3, 0, tunic),
        B(0.76, 0.11, 0.48, 0, 0.87, 0, "#2a1d14"),
        B(0.14, 0.13, 0.05, 0, 0.87, 0.25, "#f2b84b"),
        B(0.52, 0.13, 0.5, 0, 1.66, 0, "#e6dcc0"),
        B(0.42, 0.5, 0.2, 0, 1.25, -0.33, "#7a5a3a"),
        B(0.44, 0.1, 0.22, 0, 1.45, -0.33, "#5e432b"),
        S(0.27, 0, 1.87, 0, skin, 8, 6),
        B(0.06, 0.09, 0.07, 0, 1.85, 0.27, "#d9a070"),
        B(0.07, 0.07, 0.05, -0.1, 1.91, 0.25, "#222222"),
        B(0.07, 0.07, 0.05, 0.1, 1.91, 0.25, "#222222"),
        B(0.09, 0.03, 0.04, -0.1, 1.98, 0.25, hair),
        B(0.09, 0.03, 0.04, 0.1, 1.98, 0.25, hair),
        B(0.5, 0.2, 0.12, 0, 1.9, -0.2, hair),
        C(0.5, 0.5, 0.05, 0, 2.0, 0, hat, 12),
        C(0.2, 0.25, 0.24, 0, 2.12, 0, hat, 12),
        C(0.26, 0.26, 0.06, 0, 2.04, 0, band, 12),
    ]
    if beard:
        p.append(B(0.34, 0.2, 0.14, 0, 1.68, 0.2, "#d8d2c4"))
    p += lg("armL", -0.47, 1.6, 0, 0.2, 0.72, 0.22, tunic)
    p += lg("armR", 0.47, 1.6, 0, 0.2, 0.72, 0.22, tunic)
    p.append(B(0.2, 0.08, 0.24, -0.47, 1.0, 0, "#d9c9a0", n="armL", pv=[-0.47, 1.6, 0]))
    p.append(B(0.2, 0.08, 0.24, 0.47, 1.0, 0, "#d9c9a0", n="armR", pv=[0.47, 1.6, 0]))
    p.append(B(0.18, 0.15, 0.2, -0.47, 0.93, 0, skin, n="armL", pv=[-0.47, 1.6, 0]))
    p.append(B(0.18, 0.15, 0.2, 0.47, 0.93, 0, skin, n="armR", pv=[0.47, 1.6, 0]))
    return p


# --- اجزای نرم و ارگانیک برای شخصیت‌های انسانی (sm=سایه‌زنی نرم، sc=کشیدگی) ---
def SS(rad, x, y, z, c, sc=None, **k):
    d = dict(t="sph", s=[rad, 16, 12], p=[x, y, z], c=c, sm=1, **k)
    if sc:
        d["sc"] = sc
    return d


def CC(rt, rb, h, x, y, z, c, sc=None, seg=16, **k):
    d = dict(t="cyl", s=[rt, rb, h, seg], p=[x, y, z], c=c, sm=1, **k)
    if sc:
        d["sc"] = sc
    return d


def TT(R, tube, x, y, z, c, sc=None, **k):
    d = dict(t="tor", s=[R, tube], p=[x, y, z], c=c, sm=1, r=[math.pi / 2, 0, 0], **k)
    if sc:
        d["sc"] = sc
    return d


def person(tunic, pants, vest, hat, band, hair, hat_kind="straw", cape=None, apron=None, beard=None,
           skin="#eab890", boot="#4a2f1c", trim="#f6f2e8", leather="#7a4a2a"):
    cheek = "#e5917c"
    p = []
    # پاها (ران و ساق مخروطی + چکمه + کف پا)
    for n, x in (("legL", -0.125), ("legR", 0.125)):
        pv = [x, 0.86, 0]
        p += [
            CC(0.125, 0.085, 0.86, x, 0.43, 0, pants, n=n, pv=pv),
            CC(0.092, 0.108, 0.36, x, 0.18, 0, boot, n=n, pv=pv),
            TT(0.105, 0.036, x, 0.37, 0, trim, n=n, pv=pv),
            SS(0.106, x, 0.075, 0.1, boot, sc=[1, 0.72, 1.85], n=n, pv=pv),
        ]
    # لگن، تنه، شانه
    p += [
        SS(0.3, 0, 0.9, 0, pants, sc=[1, 0.58, 0.7]),
        CC(0.235, 0.27, 0.42, 0, 1.08, 0, tunic, sc=[1, 1, 0.7]),
        CC(0.31, 0.235, 0.46, 0, 1.4, 0, tunic, sc=[1, 1, 0.72]),
        SS(0.125, -0.36, 1.53, 0, tunic), SS(0.125, 0.36, 1.53, 0, tunic),
        CC(0.318, 0.255, 0.5, 0, 1.36, 0, vest, sc=[1, 1, 0.76]),
        CC(0.275, 0.3, 0.12, 0, 1.2, 0.0, vest, sc=[1, 1, 0.76]),
        B(0.1, 0.5, 0.03, 0, 1.36, 0.248, tunic),
        SS(0.02, 0.07, 1.46, 0.262, "#f2b84b"), SS(0.02, 0.07, 1.28, 0.262, "#f2b84b"),
    ]
    # کمربند، کیسه، قمقمه
    p += [
        TT(0.26, 0.036, 0, 0.95, 0, "#3a2415", sc=[1, 0.72, 1]),
        B(0.1, 0.1, 0.04, 0, 0.95, 0.2, "#f2b84b"),
        SS(0.085, 0.28, 0.82, 0.16, leather, sc=[1, 1.25, 0.8]), SS(0.05, 0.28, 0.9, 0.17, "#5a3418"),
        CC(0.058, 0.058, 0.26, -0.3, 0.82, 0.14, "#8a5a3c", seg=10), SS(0.035, -0.3, 0.97, 0.14, "#d9c9a0"),
    ]
    # گردن و سر
    p += [
        CC(0.07, 0.08, 0.16, 0, 1.67, 0, skin),
        SS(0.26, 0, 1.94, 0, skin, sc=[0.88, 1.08, 0.95]),
        SS(0.19, 0, 1.8, 0.045, skin, sc=[0.95, 0.8, 0.9]),
        SS(0.042, 0, 1.885, 0.25, "#e2a47e", sc=[1, 1.35, 1.2]),
        SS(0.036, -0.085, 1.955, 0.222, "#ffffff", sc=[1.15, 0.85, 0.6]), SS(0.036, 0.085, 1.955, 0.222, "#ffffff", sc=[1.15, 0.85, 0.6]),
        SS(0.022, -0.085, 1.955, 0.242, "#2a1a10"), SS(0.022, 0.085, 1.955, 0.242, "#2a1a10"),
        SS(0.008, -0.078, 1.966, 0.262, "#ffffff"), SS(0.008, 0.092, 1.966, 0.262, "#ffffff"),
        CC(0.014, 0.014, 0.11, -0.088, 2.03, 0.228, hair, seg=6, r=[0, 0, 1.45]),
        CC(0.014, 0.014, 0.11, 0.088, 2.03, 0.228, hair, seg=6, r=[0, 0, 1.69]),
        SS(0.04, -0.15, 1.84, 0.2, cheek, sc=[1, 0.8, 0.5]), SS(0.04, 0.15, 1.84, 0.2, cheek, sc=[1, 0.8, 0.5]),
        SS(0.032, 0, 1.765, 0.238, "#b86a58", sc=[2, 0.5, 0.5]),
        SS(0.046, -0.04, 1.81, 0.248, hair, sc=[1.5, 0.55, 0.6]), SS(0.046, 0.04, 1.81, 0.248, hair, sc=[1.5, 0.55, 0.6]),
        SS(0.045, -0.24, 1.93, 0, skin, sc=[0.6, 1.2, 0.9]), SS(0.045, 0.24, 1.93, 0, skin, sc=[0.6, 1.2, 0.9]),
        # مو
        SS(0.275, 0, 1.99, -0.045, hair, sc=[0.93, 0.92, 1.0]),
        SS(0.2, 0, 1.84, -0.17, hair, sc=[1, 1.15, 0.8]),
        SS(0.1, 0, 2.11, 0.17, hair, sc=[1.7, 0.65, 0.8]),
        SS(0.06, -0.225, 1.88, 0.1, hair, sc=[0.7, 1.4, 0.7]), SS(0.06, 0.225, 1.88, 0.1, hair, sc=[0.7, 1.4, 0.7]),
    ]
    if beard:
        p += [SS(0.14, 0, 1.73, 0.12, beard, sc=[1, 1.15, 0.8]), SS(0.05, -0.05, 1.8, 0.255, beard, sc=[1.6, 0.6, 0.6]), SS(0.05, 0.05, 1.8, 0.255, beard, sc=[1.6, 0.6, 0.6])]
    # کلاه
    if hat_kind == "straw":
        p += [
            CC(0.6, 0.67, 0.05, 0, 2.15, 0, "#dcbf72", seg=20),
            TT(0.64, 0.025, 0, 2.13, 0, "#b99a4e", sc=[1, 1, 1]),
            CC(0.22, 0.28, 0.3, 0, 2.3, 0, "#e8cf86", seg=18),
            SS(0.22, 0, 2.45, 0, "#dcbf72", sc=[1.0, 0.38, 1.0]),
            TT(0.272, 0.036, 0, 2.2, 0, band),
            SS(0.04, 0.3, 2.38, 0.1, "#4fa86b", sc=[0.6, 3.4, 0.9], r=[0.2, 0, -0.5]),
            SS(0.035, 0.34, 2.35, 0.06, "#f1e6c0", sc=[0.6, 3.0, 0.9], r=[0.2, 0, -0.6]),
        ]
    else:
        p += [SS(0.3, 0, 2.1, 0, hat, sc=[1, 0.7, 1.08]), TT(0.275, 0.05, 0, 2.03, 0, band), SS(0.06, 0, 2.38, 0, band)]
    # شنل
    if cape:
        p += [
            SS(0.52, 0, 1.6, -0.03, cape, sc=[1, 0.3, 0.68]),
            TT(0.34, 0.065, 0, 1.52, -0.03, trim, sc=[1, 1, 1.1]),
            B(0.8, 0.95, 0.07, 0, 1.03, -0.3, cape, n="cape", pv=[0, 1.5, -0.3]),
            B(0.82, 0.06, 0.09, 0, 0.8, -0.3, "#f2b84b", n="cape", pv=[0, 1.5, -0.3]),
            B(0.84, 0.08, 0.1, 0, 0.6, -0.3, trim, n="cape", pv=[0, 1.5, -0.3]),
            CC(0.11, 0.11, 0.7, 0, 1.2, -0.42, "#d9c9a0", seg=12, r=[0, 0, 1.5708]),
            B(0.06, 0.26, 0.26, -0.2, 1.2, -0.42, leather), B(0.06, 0.26, 0.26, 0.2, 1.2, -0.42, leather),
        ]
    if apron:
        p += [B(0.5, 0.62, 0.03, 0, 1.05, 0.26, apron), B(0.34, 0.2, 0.03, 0, 1.46, 0.25, apron)]
    # دستمال گردن
    p += [TT(0.115, 0.048, 0, 1.64, 0, "#c0392b"), dict(t="cone", s=[0.1, 0.22, 4], p=[0, 1.52, 0.13], c="#c0392b", r=[math.pi, 0, 0], sm=1)]
    # دست‌ها (بازوی مخروطی، سرآستین، کف دست)
    for n, x in (("armL", -0.37), ("armR", 0.37)):
        pv = [x, 1.55, 0]
        p += [
            CC(0.078, 0.06, 0.74, x, 1.18, 0, tunic, n=n, pv=pv),
            TT(0.066, 0.026, x, 0.86, 0, leather, n=n, pv=pv),
            SS(0.063, x, 0.8, 0.01, skin, sc=[1, 1.2, 0.9], n=n, pv=pv),
            SS(0.026, x + (0.04 if x < 0 else -0.04), 0.81, 0.07, skin, n=n, pv=pv),
        ]
    return p


def shepherd():
    return person("#eadfc4", "#6b5a45", "#7a4a2a", "#dcbf72", "#b5382c", "#5a3a22", "straw", cape="#b5382c")


def merchant():
    return person("#e6e0d0", "#3a3a44", "#2d4a66", "#7a2e2e", "#f2b84b", "#8a8a8a", "cap", beard="#d8d2c4", apron="#efe6cf", boot="#3a2a1c", skin="#e3ae84")


def sheep(ram=False):
    wool = "#e9e2d0" if ram else "#f6f3ea"
    wool2 = "#d9d1bb" if ram else "#e8e3d4"
    face = "#2b2622" if ram else "#4a4038"
    hp = [0, 1.05, 0.62]
    p = [
        B(0.92, 0.72, 1.25, 0, 0.95, 0, wool),
        S(0.55, 0, 1.3, 0.05, wool),
        S(0.44, 0, 1.25, -0.42, wool2),
        S(0.42, 0, 1.0, -0.64, wool),
        S(0.38, -0.38, 1.05, 0.35, wool), S(0.38, 0.38, 1.05, 0.35, wool),
        S(0.38, -0.38, 1.0, -0.3, wool2), S(0.38, 0.38, 1.0, -0.3, wool2),
        S(0.34, 0, 0.98, 0.58, wool),
        B(0.4, 0.4, 0.44, 0, 1.05, 0.85, face, n="head", pv=hp),
        B(0.22, 0.14, 0.12, 0, 0.97, 1.1, "#7a6a5d", n="head", pv=hp),
        B(0.1, 0.05, 0.04, -0.06, 1.0, 1.17, "#171210", n="head", pv=hp),
        B(0.1, 0.05, 0.04, 0.06, 1.0, 1.17, "#171210", n="head", pv=hp),
        S(0.2, 0, 1.3, 0.8, wool, n="head", pv=hp),
        B(0.17, 0.07, 0.24, -0.29, 1.12, 0.78, face, n="head", pv=hp, r=[0, 0, 0.5]),
        B(0.17, 0.07, 0.24, 0.29, 1.12, 0.78, face, n="head", pv=hp, r=[0, 0, -0.5]),
        B(0.08, 0.08, 0.04, -0.12, 1.14, 1.07, "#f2f2f2", n="head", pv=hp),
        B(0.08, 0.08, 0.04, 0.12, 1.14, 1.07, "#f2f2f2", n="head", pv=hp),
        B(0.04, 0.04, 0.03, -0.12, 1.14, 1.09, "#111", n="head", pv=hp),
        B(0.04, 0.04, 0.03, 0.12, 1.14, 1.09, "#111", n="head", pv=hp),
        S(0.14, 0, 1.0, -0.8, wool),
    ]
    if ram:
        horn = "#d8c79b"
        for sx in (-1, 1):
            p.append(B(0.12, 0.12, 0.26, 0.27 * sx, 1.27, 0.72, horn, n="head", pv=hp))
            p.append(B(0.12, 0.26, 0.12, 0.35 * sx, 1.16, 0.74, horn, n="head", pv=hp))
            p.append(B(0.12, 0.12, 0.2, 0.33 * sx, 1.0, 0.8, horn, n="head", pv=hp))
            p.append(B(0.09, 0.09, 0.1, 0.33 * sx, 1.0, 0.94, "#c9b783", n="head", pv=hp))
    for n, x, z in (("legFL", -0.28, 0.45), ("legFR", 0.28, 0.45), ("legBL", -0.28, -0.45), ("legBR", 0.28, -0.45)):
        p += lg(n, x, 0.6, z, 0.15, 0.6, 0.15, "#3b312b", "#1c1714", 0.1)
    return p


def wolf():
    fur, dark, light, hp = "#6f7480", "#4e525b", "#9aa0ac", [0, 1.1, 0.8]
    p = [
        B(0.62, 0.66, 1.5, 0, 0.95, 0, fur),
        B(0.8, 0.62, 0.55, 0, 1.03, 0.45, "#858a96"),
        B(0.3, 0.1, 1.35, 0, 1.3, -0.05, dark),
        B(0.4, 0.3, 0.5, 0, 0.78, 0.55, light),
        B(0.66, 0.5, 0.5, 0, 0.95, -0.5, "#656a75"),
        B(0.5, 0.42, 0.4, 0, 1.12, 0.82, "#7a7f8a"),
        B(0.5, 0.4, 0.5, 0, 1.15, 1.05, "#7f8490", n="head", pv=hp),
        B(0.58, 0.2, 0.3, 0, 1.0, 0.96, light, n="head", pv=hp),
        B(0.26, 0.2, 0.42, 0, 1.08, 1.46, "#4a4d55", n="head", pv=hp),
        B(0.22, 0.07, 0.34, 0, 0.96, 1.42, "#2f3036", n="head", pv=hp),
        B(0.1, 0.09, 0.08, 0, 1.15, 1.68, "#0e0e10", n="head", pv=hp),
        B(0.03, 0.06, 0.03, -0.07, 0.99, 1.62, "#f4f0e2", n="head", pv=hp),
        B(0.03, 0.06, 0.03, 0.07, 0.99, 1.62, "#f4f0e2", n="head", pv=hp),
        K(0.11, 0.28, -0.16, 1.5, 1.0, dark, 4, n="head", pv=hp),
        K(0.11, 0.28, 0.16, 1.5, 1.0, dark, 4, n="head", pv=hp),
        B(0.08, 0.06, 0.04, -0.14, 1.22, 1.3, "#ffcc33", n="head", pv=hp),
        B(0.08, 0.06, 0.04, 0.14, 1.22, 1.3, "#ffcc33", n="head", pv=hp),
        B(0.03, 0.04, 0.03, -0.14, 1.22, 1.32, "#c00000", n="head", pv=hp),
        B(0.03, 0.04, 0.03, 0.14, 1.22, 1.32, "#c00000", n="head", pv=hp),
        B(0.24, 0.22, 0.8, 0, 1.0, -1.1, "#5c616c", r=[-0.55, 0, 0]),
        B(0.2, 0.2, 0.3, 0, 0.78, -1.5, "#cfd3da", r=[-0.55, 0, 0]),
    ]
    for n, x, z in (("legFL", -0.21, 0.55), ("legFR", 0.21, 0.55), ("legBL", -0.21, -0.55), ("legBR", 0.21, -0.55)):
        p += lg(n, x, 0.65, z, 0.17, 0.65, 0.17, dark, "#2a2b30", 0.1)
    return p


def boar():
    hide, hp = "#5a4535", [0, 0.85, 0.75]
    p = [
        B(0.9, 0.8, 1.5, 0, 0.85, 0, hide),
        B(0.95, 0.7, 0.6, 0, 0.95, 0.5, "#4d3b2e"),
        B(0.7, 0.55, 0.5, 0, 0.8, -0.55, "#4d3b2e"),
        B(0.92, 0.12, 1.3, 0, 0.45, 0, "#8a6a52"),
        B(0.22, 0.12, 1.35, 0, 1.3, 0, "#241a14"),
        B(0.62, 0.56, 0.6, 0, 0.85, 1.0, "#3f2f25", n="head", pv=hp),
        B(0.34, 0.28, 0.3, 0, 0.74, 1.42, "#c58b72", n="head", pv=hp),
        B(0.3, 0.06, 0.1, 0, 0.7, 1.58, "#8a5a46", n="head", pv=hp),
        B(0.06, 0.12, 0.05, -0.22, 0.68, 1.5, "#f4f0e2", n="head", pv=hp),
        B(0.06, 0.12, 0.05, 0.22, 0.68, 1.5, "#f4f0e2", n="head", pv=hp),
        B(0.06, 0.12, 0.08, -0.22, 0.78, 1.58, "#e8e0cc", n="head", pv=hp, r=[-0.5, 0, 0]),
        B(0.06, 0.12, 0.08, 0.22, 0.78, 1.58, "#e8e0cc", n="head", pv=hp, r=[-0.5, 0, 0]),
        K(0.1, 0.22, -0.2, 1.2, 0.95, "#2f241b", 4, n="head", pv=hp),
        K(0.1, 0.22, 0.2, 1.2, 0.95, "#2f241b", 4, n="head", pv=hp),
        B(0.07, 0.06, 0.04, -0.17, 0.98, 1.3, "#ffd34d", n="head", pv=hp),
        B(0.07, 0.06, 0.04, 0.17, 0.98, 1.3, "#ffd34d", n="head", pv=hp),
        B(0.08, 0.08, 0.28, 0, 0.98, -0.88, "#2a2019", r=[-0.7, 0, 0]),
    ]
    for i in range(6):
        p.append(K(0.09, 0.28, 0, 1.32, 0.5 - i * 0.22, "#241a14", 4))
    for n, x, z in (("legFL", -0.3, 0.5), ("legFR", 0.3, 0.5), ("legBL", -0.3, -0.5), ("legBR", 0.3, -0.5)):
        p += lg(n, x, 0.45, z, 0.2, 0.45, 0.2, "#2f241b", "#16100c", 0.1)
    return p


def dog():
    fur, hp = "#c4965e", [0, 0.9, 0.5]
    p = [
        B(0.42, 0.45, 0.95, 0, 0.68, 0, fur),
        B(0.44, 0.1, 0.55, 0, 0.9, -0.05, "#7a5632"),
        B(0.3, 0.3, 0.36, 0, 0.7, 0.4, "#f1e6cf"),
        B(0.46, 0.09, 0.14, 0, 0.84, 0.35, "#c0392b"),
        B(0.1, 0.1, 0.05, 0, 0.78, 0.41, "#f2b84b"),
        B(0.32, 0.32, 0.4, 0, 0.95, 0.65, fur, n="head", pv=hp),
        B(0.2, 0.16, 0.24, 0, 0.88, 0.93, "#f1e6cf", n="head", pv=hp),
        B(0.1, 0.07, 0.06, 0, 0.93, 1.06, "#111", n="head", pv=hp),
        B(0.07, 0.03, 0.12, 0, 0.8, 1.0, "#e87a8a", n="head", pv=hp),
        B(0.07, 0.07, 0.04, -0.1, 1.03, 0.85, "#111", n="head", pv=hp),
        B(0.07, 0.07, 0.04, 0.1, 1.03, 0.85, "#111", n="head", pv=hp),
        B(0.1, 0.2, 0.08, -0.17, 1.14, 0.58, "#6b4a2a", n="head", pv=hp, r=[0, 0, 0.3]),
        B(0.1, 0.2, 0.08, 0.17, 1.14, 0.58, "#6b4a2a", n="head", pv=hp, r=[0, 0, -0.3]),
        B(0.11, 0.11, 0.5, 0, 0.98, -0.62, "#8a6a40", r=[-0.75, 0, 0]),
        B(0.12, 0.12, 0.14, 0, 1.2, -0.85, "#f1e6cf", r=[-0.75, 0, 0]),
    ]
    for n, x, z in (("legFL", -0.14, 0.32), ("legFR", 0.14, 0.32), ("legBL", -0.14, -0.32), ("legBR", 0.14, -0.32)):
        p += lg(n, x, 0.45, z, 0.12, 0.45, 0.12, "#a07848", "#f1e6cf", 0.12)
    return p


def horse():
    coat, mane, hp = "#8b5a2b", "#241810", [0, 2.3, 1.2]
    p = [
        B(0.85, 0.9, 1.9, 0, 1.55, 0, coat),
        B(0.8, 0.5, 0.5, 0, 1.45, 0.75, "#966330"),
        B(0.78, 0.3, 0.6, 0, 1.3, -0.7, "#7d4f25"),
        B(0.88, 0.1, 0.8, 0, 2.03, 0, "#7a1f1f"),
        B(0.9, 0.05, 0.84, 0, 2.0, 0, "#c9a24a"),
        B(0.3, 0.14, 0.12, 0, 2.12, 0.42, "#5e1616"),
        B(0.3, 0.14, 0.12, 0, 2.12, -0.4, "#5e1616"),
        B(0.06, 0.4, 0.14, -0.5, 1.68, 0, "#5a3d2b"),
        B(0.06, 0.4, 0.14, 0.5, 1.68, 0, "#5a3d2b"),
        B(0.12, 0.05, 0.22, -0.5, 1.48, 0, "#aaa"),
        B(0.12, 0.05, 0.22, 0.5, 1.48, 0, "#aaa"),
        B(0.4, 0.95, 0.5, 0, 2.1, 1.0, coat, r=[0.5, 0, 0]),
        B(0.14, 0.4, 0.3, 0, 2.5, 0.78, mane, r=[0.5, 0, 0]),
        B(0.14, 0.4, 0.3, 0, 2.2, 0.6, mane, r=[0.5, 0, 0]),
        B(0.14, 0.35, 0.3, 0, 1.92, 0.4, mane, r=[0.4, 0, 0]),
        B(0.35, 0.38, 0.8, 0, 2.5, 1.45, coat, n="head", pv=hp, r=[0.6, 0, 0]),
        B(0.1, 0.4, 0.7, 0, 2.52, 1.5, "#f1e6cf", n="head", pv=hp, r=[0.6, 0, 0]),
        B(0.3, 0.22, 0.28, 0, 2.28, 1.78, "#c9a27a", n="head", pv=hp, r=[0.6, 0, 0]),
        B(0.38, 0.08, 0.1, 0, 2.55, 1.75, "#7a1f1f", n="head", pv=hp, r=[0.6, 0, 0]),
        B(0.37, 0.06, 0.1, 0, 2.4, 1.45, "#7a1f1f", n="head", pv=hp, r=[0.6, 0, 0]),
        B(0.06, 0.07, 0.04, -0.19, 2.6, 1.35, "#111", n="head", pv=hp),
        B(0.06, 0.07, 0.04, 0.19, 2.6, 1.35, "#111", n="head", pv=hp),
        K(0.07, 0.22, -0.11, 2.88, 1.22, mane, 4, n="head", pv=hp),
        K(0.07, 0.22, 0.11, 2.88, 1.22, mane, 4, n="head", pv=hp),
        B(0.18, 0.2, 0.9, 0, 1.4, -1.15, mane, r=[-0.45, 0, 0]),
        B(0.14, 0.2, 0.7, 0, 0.95, -1.5, mane, r=[-0.15, 0, 0]),
    ]
    for n, x, z in (("legFL", -0.28, 0.7), ("legFR", 0.28, 0.7), ("legBL", -0.28, -0.7), ("legBR", 0.28, -0.7)):
        p += lg(n, x, 1.1, z, 0.21, 1.1, 0.21, "#6f4721", "#1c1410", 0.16)
        p.append(B(0.23, 0.18, 0.23, x, 0.28, z + 0.02, "#f1e6cf", n=n, pv=[x, 1.1, z]))
    return p


def pine():
    p = [C(0.2, 0.34, 1.3, 0, 0.65, 0, "#5a3d2b", 6), C(0.34, 0.5, 0.2, 0, 0.1, 0, "#4a3022", 6)]
    layers = [(1.9, 1.7, 1.7, "#2a6140"), (1.6, 1.6, 2.5, "#2f6b45"), (1.3, 1.5, 3.3, "#3a7d50"), (1.0, 1.4, 4.1, "#44895a"), (0.65, 1.3, 4.9, "#4f9a64")]
    for r, h, y, c in layers:
        p.append(K(r, h, 0, y, 0, c, 8))
    p.append(K(0.12, 0.4, 0, 5.75, 0, "#7fc080", 5))
    return p


def oak():
    return [
        C(0.24, 0.34, 1.6, 0, 0.8, 0, "#6b4a30", 6),
        C(0.4, 0.55, 0.25, 0, 0.12, 0, "#5a3d2b", 6),
        B(0.14, 0.9, 0.14, 0.4, 1.9, 0, "#6b4a30", r=[0, 0, -0.7]),
        B(0.14, 0.8, 0.14, -0.4, 1.9, 0.1, "#6b4a30", r=[0, 0, 0.7]),
        S(1.5, 0, 2.8, 0, "#5f9f4a", 8, 6),
        S(1.1, 1.0, 2.4, 0.3, "#6fae52", 7, 5),
        S(1.1, -0.9, 2.5, -0.3, "#548f42", 7, 5),
        S(0.9, 0.2, 3.5, -0.4, "#74b85a", 7, 5),
        S(0.8, -0.3, 2.2, 0.9, "#5a9a46", 7, 5),
    ]


def birch():
    p = [C(0.14, 0.2, 2.8, 0, 1.4, 0, "#ece8dc", 6)]
    for y in (0.6, 1.2, 1.9, 2.4):
        p.append(B(0.34, 0.07, 0.34, 0, y, 0, "#2b2b2b"))
    p += [S(1.1, 0, 3.2, 0, "#a8c957", 7, 5), S(0.8, 0.7, 2.7, 0.2, "#b9d664", 7, 5), S(0.8, -0.6, 2.8, -0.2, "#9cbf4d", 7, 5)]
    return p


def bush():
    return [
        S(0.7, 0, 0.45, 0, "#4f8f45", 7, 5), S(0.55, 0.5, 0.38, 0.2, "#5fa04f", 7, 5), S(0.5, -0.45, 0.35, -0.1, "#468540", 7, 5),
        B(0.1, 0.1, 0.1, 0.3, 0.7, 0.4, "#d6402e"), B(0.1, 0.1, 0.1, -0.2, 0.62, 0.5, "#d6402e"), B(0.1, 0.1, 0.1, 0.0, 0.85, 0.2, "#d6402e"),
    ]


def reed():
    return [C(0.025, 0.04, 1.4, 0, 0.7, 0, "#6a8a3a", 4), C(0.06, 0.06, 0.28, 0, 1.4, 0, "#6b4a2d", 5),
            C(0.02, 0.035, 1.1, 0.15, 0.55, 0.05, "#7a9a45", 4, r=[0, 0, -0.12])]


def cloud():
    return [S(2.2, 0, 0, 0, "#ffffff", 7, 5), S(1.7, 2.2, -0.3, 0.3, "#f6f8ff", 7, 5), S(1.6, -2.1, -0.3, -0.2, "#f6f8ff", 7, 5), S(1.3, 0.6, 0.8, 0.2, "#ffffff", 7, 5)]


def rock():
    return [D(1.0, 0, 0.5, 0, "#8b8f94"), D(0.6, 0.7, 0.3, 0.3, "#a0a4a8"), D(0.45, -0.7, 0.25, -0.4, "#7b7f84"), D(0.5, 0.05, 0.98, 0.0, "#6f9a58")]


def fence():
    wood = "#9b7b55"
    return [
        B(0.16, 1.05, 0.16, -1, 0.52, 0, wood), B(0.16, 1.05, 0.16, 1, 0.52, 0, wood),
        B(0.22, 0.06, 0.22, -1, 1.08, 0, "#7a5a3a"), B(0.22, 0.06, 0.22, 1, 1.08, 0, "#7a5a3a"),
        B(2.1, 0.09, 0.07, 0, 0.84, 0.05, "#b4936a"), B(2.1, 0.09, 0.07, 0, 0.5, -0.05, "#b4936a"),
        B(0.06, 0.8, 0.05, 0, 0.5, 0, "#8a6b48", r=[0, 0, 0.9]),
    ]


def gate():
    wood = "#7a5a3a"
    return [
        B(0.34, 2.8, 0.34, -2.2, 1.4, 0, wood), B(0.34, 2.8, 0.34, 2.2, 1.4, 0, wood),
        B(0.5, 0.12, 0.5, -2.2, 2.85, 0, "#5a3d2b"), B(0.5, 0.12, 0.5, 2.2, 2.85, 0, "#5a3d2b"),
        B(4.9, 0.3, 0.3, 0, 2.7, 0, wood),
        B(1.7, 0.55, 0.08, 0, 2.2, 0, "#e6dcc0"), B(1.4, 0.06, 0.1, 0, 2.2, 0.02, "#b5543a"),
        C(0.02, 0.02, 0.45, -0.6, 2.45, 0, "#444", 4), C(0.02, 0.02, 0.45, 0.6, 2.45, 0, "#444", 4),
        S(0.14, -2.0, 2.4, 0.3, "#ffd27a"), B(0.04, 0.3, 0.04, -2.0, 2.58, 0.3, "#333"),
    ]


def flag():
    return [C(0.04, 0.05, 2.6, 0, 1.3, 0, "#6b4a2d", 5), B(0.78, 0.42, 0.03, 0.4, 2.3, 0, "#d6402e"), B(0.78, 0.1, 0.04, 0.4, 2.3, 0, "#f4f0e2"), S(0.07, 0, 2.65, 0, "#f2b84b")]


def market():
    p = [
        B(3.4, 0.95, 1.0, 0, 0.475, 0.5, "#8a5a3c"),
        B(3.4, 0.12, 1.02, 0, 0.2, 0.5, "#6d4a30"),
        B(3.6, 0.1, 1.2, 0, 1.0, 0.5, "#b7895a"),
        B(3.4, 2.0, 0.1, 0, 1.0, -0.7, "#6d4a30"),
        B(0.55, 0.38, 0.5, -1.2, 1.24, 0.5, "#f4f1ea"), S(0.28, -1.2, 1.5, 0.5, "#f4f1ea"),
        B(0.5, 0.26, 0.4, -0.3, 1.18, 0.5, "#b83b3b"), B(0.4, 0.2, 0.32, -0.3, 1.4, 0.5, "#c94a4a"),
        B(0.65, 0.12, 0.5, 0.7, 1.11, 0.5, "#9a6b42"), B(0.6, 0.1, 0.46, 0.7, 1.21, 0.5, "#b88958"),
        C(0.17, 0.17, 0.3, 1.35, 1.2, 0.5, "#f2b84b", 10), C(0.17, 0.17, 0.2, 1.35, 1.45, 0.5, "#f7c864", 10),
        B(0.5, 0.7, 0.04, -1.0, 1.5, -0.62, "#f4f1ea"), B(0.5, 0.7, 0.04, 0.0, 1.5, -0.62, "#9a6b42"), B(0.5, 0.7, 0.04, 1.0, 1.5, -0.62, "#7a5232"),
        B(0.5, 0.5, 0.5, 1.9, 0.25, 0.9, "#a47a4a"), B(0.45, 0.45, 0.45, 2.0, 0.72, 0.9, "#b88958"),
        S(0.3, -1.95, 0.3, 0.9, "#c9b890"),
        B(2.6, 0.5, 0.1, 0, 3.55, 1.25, "#e6dcc0"), B(2.2, 0.08, 0.12, 0, 3.55, 1.26, "#b5543a"),
        S(0.12, -1.7, 2.9, 1.1, "#ffd27a"),
    ]
    for sx in (-1.7, 1.7):
        for sz in (-0.7, 1.1):
            p.append(C(0.08, 0.08, 3.0, sx, 1.5, sz, "#5a3d2b", 6))
    for i in range(6):
        p.append(B(0.62, 0.12, 2.5, -1.55 + i * 0.62, 3.05, 0.2, "#c0553a" if i % 2 == 0 else "#f1ead8", r=[0.12, 0, 0]))
        p.append(B(0.62, 0.3, 0.06, -1.55 + i * 0.62, 2.88, 1.43, "#c0553a" if i % 2 == 0 else "#f1ead8"))
    return p


def trough():
    return [
        B(3.0, 0.5, 0.95, 0, 0.35, 0, "#7a5a3a"), B(2.7, 0.06, 0.65, 0, 0.58, 0, "#4ea8de"),
        B(0.14, 0.7, 0.14, -1.45, 0.35, 0.4, "#5a3d2b"), B(0.14, 0.7, 0.14, 1.45, 0.35, 0.4, "#5a3d2b"),
        B(0.14, 0.7, 0.14, -1.45, 0.35, -0.4, "#5a3d2b"), B(0.14, 0.7, 0.14, 1.45, 0.35, -0.4, "#5a3d2b"),
        B(0.9, 0.35, 0.7, 2.2, 0.18, 0.2, "#d8bd62"), B(0.8, 0.25, 0.6, 2.25, 0.46, 0.2, "#e6cd72"),
    ]


def hut():
    return [
        B(4.4, 0.4, 3.8, 0, 0.2, 0, "#8b8f94"),
        B(4.0, 2.2, 3.4, 0, 1.5, 0, "#b08a5e"),
        B(0.3, 2.3, 0.3, -2.0, 1.55, 1.7, "#6d4a30"), B(0.3, 2.3, 0.3, 2.0, 1.55, 1.7, "#6d4a30"),
        B(0.3, 2.3, 0.3, -2.0, 1.55, -1.7, "#6d4a30"), B(0.3, 2.3, 0.3, 2.0, 1.55, -1.7, "#6d4a30"),
        K(3.8, 2.0, 0, 3.6, 0, "#8a3b2c", 4, r=[0, math.pi / 4, 0]),
        K(3.9, 0.3, 0, 2.7, 0, "#6e2d21", 4, r=[0, math.pi / 4, 0]),
        B(0.7, 1.5, 0.7, 1.2, 4.0, -0.5, "#8b8f94"), B(0.85, 0.15, 0.85, 1.2, 4.8, -0.5, "#6f7378"),
        B(1.0, 1.7, 0.12, 0, 1.25, 1.72, "#4a3322"), B(1.2, 0.12, 0.16, 0, 2.15, 1.72, "#6d4a30"), S(0.07, 0.3, 1.2, 1.8, "#f2b84b"),
        B(0.9, 0.7, 0.1, 1.3, 1.9, 1.72, "#9ad0e8"), B(1.05, 0.08, 0.14, 1.3, 2.28, 1.72, "#6d4a30"), B(1.05, 0.08, 0.14, 1.3, 1.52, 1.72, "#6d4a30"),
        B(2.0, 0.2, 0.8, 0, 0.35, 2.2, "#8b8f94"),
    ]


def staff():
    return [C(0.045, 0.045, 2.2, 0, 0.45, 0, "#6b4a2d", 6), B(0.3, 0.07, 0.07, 0.12, 1.55, 0, "#6b4a2d"), B(0.07, 0.25, 0.07, 0.27, 1.45, 0, "#6b4a2d"),
            C(0.055, 0.055, 0.25, 0, 0.1, 0, "#3a2a1c", 6), C(0.05, 0.05, 0.1, 0, -0.55, 0, "#9a9a9a", 6)]


def bow():
    wood = "#7a4a22"
    return [
        B(0.07, 0.16, 0.2, 0, -0.3, 0, wood), B(0.09, 0.1, 0.12, 0, -0.3, 0, "#3a2a1c"),
        B(0.05, 0.05, 0.5, 0, -0.24, 0.34, wood, r=[-0.5, 0, 0]), B(0.05, 0.05, 0.5, 0, -0.24, -0.34, wood, r=[0.5, 0, 0]),
        B(0.05, 0.05, 0.25, 0, -0.1, 0.68, wood, r=[-1.0, 0, 0]), B(0.05, 0.05, 0.25, 0, -0.1, -0.68, wood, r=[1.0, 0, 0]),
        B(0.012, 0.012, 1.3, 0, -0.04, 0, "#eeeeee"),
        B(0.03, 0.6, 0.03, 0, -0.35, 0, "#d8d0b0"), K(0.05, 0.12, 0, -0.7, 0, "#999", 4, r=[math.pi, 0, 0]),
    ]


def rifle():
    return [
        B(0.07, 1.25, 0.07, 0, -0.5, 0, "#2d2d33"), B(0.1, 0.1, 0.1, 0, -1.12, 0, "#1a1a1e"),
        B(0.11, 0.42, 0.15, 0, 0.12, -0.02, "#7a4a22"), B(0.09, 0.34, 0.1, 0, -0.1, -0.02, "#4a3322"),
        B(0.05, 0.05, 0.14, 0, -0.2, 0.09, "#222"), B(0.04, 0.1, 0.04, 0, -0.95, 0.08, "#222"),
        B(0.1, 0.1, 0.07, 0, -0.35, 0.1, "#333"),
    ]


MODELS = {
    "shepherd": shepherd(),
    "merchant": merchant(),
    "ewe": sheep(False), "ram": sheep(True), "wolf": wolf(), "boar": boar(), "dog": dog(), "horse": horse(),
    "pine": pine(), "oak": oak(), "birch": birch(), "bush": bush(), "reed": reed(), "cloud": cloud(), "rock": rock(),
    "fence": fence(), "gate": gate(), "flag": flag(), "market": market(), "trough": trough(), "hut": hut(),
    "staff": staff(), "bow": bow(), "rifle": rifle(),
}


# ---------------------------------------------------------------- 2D art (SVG)
def merchant_svg():
    return """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 240" role="img" aria-label="فروشنده">
<defs>
<radialGradient id="mBg" cx="50%" cy="38%" r="75%"><stop offset="0" stop-color="#ffeec4"/><stop offset="1" stop-color="#e2ad5e"/></radialGradient>
<linearGradient id="mSkin" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f3c39b"/><stop offset="1" stop-color="#dd9f74"/></linearGradient>
<linearGradient id="mCap" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#c24545"/><stop offset="1" stop-color="#7f2222"/></linearGradient>
<linearGradient id="mVest" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#37597a"/><stop offset="1" stop-color="#223a52"/></linearGradient>
<linearGradient id="mWood" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#c99a66"/><stop offset="1" stop-color="#8a5a3c"/></linearGradient>
<radialGradient id="mGlow" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#fff3b0" stop-opacity=".95"/><stop offset="1" stop-color="#fff3b0" stop-opacity="0"/></radialGradient>
</defs>
<rect width="200" height="240" fill="url(#mBg)"/>
<circle cx="30" cy="70" r="30" fill="url(#mGlow)"/>
<line x1="30" y1="40" x2="30" y2="56" stroke="#5a3d2b" stroke-width="2"/><rect x="24" y="56" width="12" height="16" rx="4" fill="#ffd27a" stroke="#5a3d2b" stroke-width="2"/>
<g>
<path d="M0 0H200V40H0Z" fill="#f4efe2"/>
<path d="M0 0H40V40H0ZM80 0H120V40H80ZM160 0H200V40H160Z" fill="#c0553a"/>
<g fill="#c0553a"><circle cx="20" cy="40" r="20"/><circle cx="100" cy="40" r="20"/><circle cx="180" cy="40" r="20"/></g>
<g fill="#f4efe2"><circle cx="60" cy="40" r="20"/><circle cx="140" cy="40" r="20"/></g>
<path d="M0 58Q20 66 40 58T80 58T120 58T160 58T200 58" fill="none" stroke="#00000018" stroke-width="3"/>
</g>
<path d="M26 240C26 182 58 160 100 160C142 160 174 182 174 240Z" fill="url(#mVest)"/>
<path d="M80 160L100 204L120 160Z" fill="#efe6cf"/>
<path d="M60 240L67 190Q100 204 133 190L140 240Z" fill="#f3ead4"/>
<path d="M67 190Q100 204 133 190" fill="none" stroke="#d9cdb0" stroke-width="2"/>
<path d="M74 168L68 192M126 168L132 192" stroke="#f3ead4" stroke-width="5" stroke-linecap="round"/>
<rect x="91" y="138" width="18" height="26" rx="8" fill="#d79a70"/>
<ellipse cx="61" cy="112" rx="7" ry="11" fill="#e2a47e"/><ellipse cx="139" cy="112" rx="7" ry="11" fill="#e2a47e"/>
<ellipse cx="100" cy="106" rx="39" ry="45" fill="url(#mSkin)"/>
<path d="M63 108Q64 170 100 175Q136 170 137 108Q126 136 100 136Q74 136 63 108Z" fill="#d9d4c6"/>
<path d="M70 130Q76 160 100 168" fill="none" stroke="#fff" stroke-opacity=".5" stroke-width="3" stroke-linecap="round"/>
<path d="M76 127Q89 114 100 124Q111 114 124 127Q111 136 100 131Q89 136 76 127Z" fill="#ece8dc"/>
<path d="M91 142Q100 150 109 142" fill="none" stroke="#8a4a3a" stroke-width="3" stroke-linecap="round"/>
<ellipse cx="100" cy="115" rx="8" ry="10" fill="#e3a67f"/>
<circle cx="76" cy="118" r="8" fill="#e8927c" opacity=".45"/><circle cx="124" cy="118" r="8" fill="#e8927c" opacity=".45"/>
<ellipse cx="84" cy="102" rx="7" ry="6" fill="#fff"/><ellipse cx="116" cy="102" rx="7" ry="6" fill="#fff"/>
<circle cx="85" cy="103" r="3.6" fill="#2a1a10"/><circle cx="115" cy="103" r="3.6" fill="#2a1a10"/>
<circle cx="86.4" cy="101.6" r="1.2" fill="#fff"/><circle cx="116.4" cy="101.6" r="1.2" fill="#fff"/>
<path d="M72 93Q84 82 96 91M104 91Q116 82 128 93" fill="none" stroke="#c9c4b6" stroke-width="6" stroke-linecap="round"/>
<path d="M58 86Q58 42 100 40Q142 42 142 86Q100 72 58 86Z" fill="url(#mCap)"/>
<path d="M56 86Q100 70 144 86L144 95Q100 80 56 95Z" fill="#f2b84b"/>
<path d="M70 62Q80 48 100 46" fill="none" stroke="#fff" stroke-opacity=".28" stroke-width="5" stroke-linecap="round"/>
<circle cx="100" cy="38" r="9" fill="#f7c864"/><circle cx="97" cy="35" r="3" fill="#fff" opacity=".55"/>
<path d="M0 204H200V240H0Z" fill="url(#mWood)"/>
<path d="M0 200H200V210H0Z" fill="#dcb07c"/><path d="M0 210H200" stroke="#6d4a30" stroke-width="2"/>
<path d="M0 224H200" stroke="#00000022" stroke-width="2"/>
<ellipse cx="68" cy="204" rx="14" ry="11" fill="#e8ad84"/><ellipse cx="132" cy="204" rx="14" ry="11" fill="#e8ad84"/>
<path d="M50 206Q56 192 70 198L72 214Z" fill="#e6e0d0"/><path d="M150 206Q144 192 130 198L128 214Z" fill="#e6e0d0"/>
<g>
<rect x="8" y="176" width="34" height="26" rx="12" fill="#f6f2ea"/><circle cx="16" cy="180" r="8" fill="#fff"/><circle cx="30" cy="177" r="9" fill="#fff"/><circle cx="38" cy="184" r="6" fill="#efe9db"/>
<rect x="150" y="186" width="30" height="18" rx="7" fill="#b83b3b"/><path d="M156 192Q165 188 174 192" stroke="#e58a8a" stroke-width="3" fill="none"/>
<ellipse cx="176" cy="200" rx="18" ry="6" fill="#9a6b42"/>
<g fill="#f2b84b" stroke="#c98d22" stroke-width="1.5"><ellipse cx="100" cy="200" rx="9" ry="3.5"/><ellipse cx="100" cy="195.5" rx="9" ry="3.5"/><ellipse cx="100" cy="191" rx="9" ry="3.5"/></g>
</g>
</svg>"""


def shepherd_svg():
    return """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120" role="img" aria-label="چوپان">
<defs>
<linearGradient id="sBg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#bfe4f2"/><stop offset=".62" stop-color="#e6f3d8"/><stop offset=".63" stop-color="#8cbc66"/><stop offset="1" stop-color="#6aa04a"/></linearGradient>
<linearGradient id="sSkin" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f1c29a"/><stop offset="1" stop-color="#dc9f75"/></linearGradient>
<linearGradient id="sHat" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f0d98f"/><stop offset="1" stop-color="#d3b463"/></linearGradient>
<linearGradient id="sCape" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#cc4a3a"/><stop offset="1" stop-color="#8f2a20"/></linearGradient>
</defs>
<rect width="120" height="120" fill="url(#sBg)"/>
<path d="M0 84Q30 70 60 80T120 74V120H0Z" fill="#7db15a"/>
<path d="M14 120Q14 96 36 92L84 92Q106 96 106 120Z" fill="url(#sCape)"/>
<path d="M14 100Q60 112 106 100" fill="none" stroke="#f6f2e8" stroke-width="7" stroke-linecap="round"/>
<path d="M42 96L60 120L78 96Z" fill="#7a4a2a"/>
<rect x="52" y="82" width="16" height="16" rx="6" fill="#d79a70"/>
<path d="M44 92Q60 106 76 92L72 100Q60 108 48 100Z" fill="#c0392b"/>
<path d="M54 98L60 112L66 98Z" fill="#c0392b"/>
<ellipse cx="38" cy="64" rx="4" ry="7" fill="#e2a47e"/><ellipse cx="82" cy="64" rx="4" ry="7" fill="#e2a47e"/>
<path d="M36 62Q34 46 60 44Q86 46 84 62Q82 72 80 74L80 58Q60 50 40 58L40 74Q36 72 36 62Z" fill="#5a3a22"/>
<ellipse cx="60" cy="64" rx="22" ry="26" fill="url(#sSkin)"/>
<path d="M38 60Q60 40 82 60Q82 50 60 46Q38 50 38 60Z" fill="#5a3a22"/>
<ellipse cx="50" cy="62" rx="4.2" ry="3.6" fill="#fff"/><ellipse cx="70" cy="62" rx="4.2" ry="3.6" fill="#fff"/>
<circle cx="50.6" cy="62.4" r="2.3" fill="#2a1a10"/><circle cx="70.6" cy="62.4" r="2.3" fill="#2a1a10"/>
<circle cx="51.4" cy="61.4" r=".8" fill="#fff"/><circle cx="71.4" cy="61.4" r=".8" fill="#fff"/>
<path d="M44 55Q50 51 56 54M64 54Q70 51 76 55" fill="none" stroke="#5a3a22" stroke-width="2.6" stroke-linecap="round"/>
<ellipse cx="60" cy="69" rx="3.6" ry="5" fill="#e0a07a"/>
<circle cx="44" cy="71" r="4.4" fill="#e5917c" opacity=".5"/><circle cx="76" cy="71" r="4.4" fill="#e5917c" opacity=".5"/>
<path d="M48 76Q54 72 60 75Q66 72 72 76Q66 80 60 78Q54 80 48 76Z" fill="#5a3a22"/>
<path d="M54 83Q60 87 66 83" fill="none" stroke="#a0503a" stroke-width="2" stroke-linecap="round"/>
<ellipse cx="60" cy="40" rx="50" ry="10" fill="url(#sHat)"/>
<ellipse cx="60" cy="43" rx="50" ry="9" fill="none" stroke="#b99a4e" stroke-width="1.5"/>
<path d="M38 40Q38 16 60 14Q82 16 82 40Q60 46 38 40Z" fill="#ecd48a"/>
<path d="M38 38Q60 46 82 38L82 33Q60 41 38 33Z" fill="#b5382c"/>
<path d="M46 26Q50 18 58 17" fill="none" stroke="#fff" stroke-opacity=".4" stroke-width="3" stroke-linecap="round"/>
<path d="M82 34Q96 20 94 8Q88 18 80 28Z" fill="#4fa86b"/><path d="M84 34Q100 28 100 14Q92 22 82 30Z" fill="#f1e6c0"/>
</svg>"""

# ---------------------------------------------------------------- world
W = 70  # نصف اندازهٔ نقشه


def gen_world(seed=7):
    rnd = random.Random(seed)
    pen = dict(x=0, z=0, half=8)
    pond = dict(x=-24, z=14, r=7)
    bog = dict(x=40, z=-28, r=10)
    cliff = dict(x=-42, z=-36, r=10)
    hut_ = dict(x=-14, z=-8, ry=0.6)
    market_ = dict(x=15, z=0, ry=-math.pi / 2)
    trough_ = dict(x=-3.5, z=-4.5, ry=0)

    keep = [
        (0, 0, 13), (0, 12, 5), (15, 0, 6), (-24, 14, 11), (40, -28, 14),
        (-42, -36, 14), (-14, -8, 6),
    ]

    def free(x, z, extra=0):
        return all(math.hypot(x - kx, z - kz) > kr + extra for kx, kz, kr in keep)

    placed = []

    def far_enough(x, z, d):
        return all(math.hypot(x - a, z - b) > d for a, b in placed)

    trees = []
    # حلقهٔ جنگل دور نقشه
    tries = 0
    while len([t for t in trees if t[5] == "rim"]) < 70 and tries < 4000:
        tries += 1
        a = rnd.uniform(0, math.tau)
        rr = rnd.uniform(W - 9, W - 2)
        x, z = math.cos(a) * rr * 0.98, math.sin(a) * rr * 0.98
        x, z = max(-W + 2, min(W - 2, x)), max(-W + 2, min(W - 2, z))
        if free(x, z) and far_enough(x, z, 3.0):
            placed.append((x, z))
            trees.append(["pine" if rnd.random() < 0.65 else "oak", round(x, 2), round(z, 2), round(rnd.uniform(0.9, 1.5), 2), round(rnd.uniform(0, 6.28), 2), "rim"])
    # جنگل شمالی (محل گراز و گرگ)
    tries = 0
    while len([t for t in trees if t[5] == "north"]) < 55 and tries < 4000:
        tries += 1
        x, z = rnd.uniform(-62, 62), rnd.uniform(-64, -46)
        if free(x, z) and far_enough(x, z, 3.2):
            placed.append((x, z))
            trees.append(["pine", round(x, 2), round(z, 2), round(rnd.uniform(0.9, 1.5), 2), round(rnd.uniform(0, 6.28), 2), "north"])
    # درخت‌های پراکنده در چمنزار
    tries = 0
    while len([t for t in trees if t[5] == "meadow"]) < 40 and tries < 4000:
        tries += 1
        x, z = rnd.uniform(-60, 60), rnd.uniform(-45, 60)
        if free(x, z, 2) and far_enough(x, z, 6):
            placed.append((x, z))
            trees.append([rnd.choice(["oak","oak","birch","pine"]), round(x, 2), round(z, 2), round(rnd.uniform(0.8, 1.3), 2), round(rnd.uniform(0, 6.28), 2), "meadow"])

    rocks = []
    for _ in range(14):  # دور پرتگاه
        a = rnd.uniform(0, math.tau)
        rr = cliff["r"] + rnd.uniform(-2, 3)
        rocks.append([round(cliff["x"] + math.cos(a) * rr, 2), round(cliff["z"] + math.sin(a) * rr, 2), round(rnd.uniform(1.0, 2.2), 2), round(rnd.uniform(0, 6), 2)])
    tries = 0
    while len(rocks) < 52 and tries < 3000:
        tries += 1
        x, z = rnd.uniform(-64, 64), rnd.uniform(-64, 64)
        if free(x, z, 1) and far_enough(x, z, 2.5):
            placed.append((x, z))
            rocks.append([round(x, 2), round(z, 2), round(rnd.uniform(0.6, 1.5), 2), round(rnd.uniform(0, 6), 2)])

    flags = []
    for zone in (bog, cliff):
        for i in range(9):
            a = i / 9 * math.tau
            flags.append([round(zone["x"] + math.cos(a) * (zone["r"] + 0.8), 2), round(zone["z"] + math.sin(a) * (zone["r"] + 0.8), 2)])

    flowers = []
    cols = ["#ffd34d", "#ff8fa3", "#ffffff", "#b49bff", "#ff9d4d"]
    while len(flowers) < 260:
        x, z = rnd.uniform(-66, 66), rnd.uniform(-66, 66)
        if free(x, z, -2):
            flowers.append([round(x, 2), round(z, 2), rnd.choice(cols)])

    patches = []
    shades = ["#86b862", "#9ccb72", "#7aab57", "#a6d07c", "#93c26a"]
    for _ in range(46):
        patches.append([round(rnd.uniform(-66, 66), 1), round(rnd.uniform(-66, 66), 1), round(rnd.uniform(3, 9), 1), rnd.choice(shades)])

    fences = []
    h = pen["half"]
    centers = [-7, -5, -3, -1, 1, 3, 5, 7]
    for c in centers:
        fences.append(dict(x=c, z=-h, ry=0))  # شمال
        if c not in (-1, 1):  # دروازه در جنوب
            fences.append(dict(x=c, z=h, ry=0))
        fences.append(dict(x=-h, z=c, ry=math.pi / 2))
        fences.append(dict(x=h, z=c, ry=math.pi / 2))

    bushes = []
    tries = 0
    while len(bushes) < 46 and tries < 3000:
        tries += 1
        x, z = rnd.uniform(-64, 64), rnd.uniform(-64, 60)
        if free(x, z, 1) and far_enough(x, z, 2.2):
            placed.append((x, z))
            bushes.append([round(x, 2), round(z, 2), round(rnd.uniform(0.8, 1.4), 2), round(rnd.uniform(0, 6), 2)])
    reeds = []
    for i in range(26):
        a = rnd.uniform(0, math.tau)
        rr = pond["r"] + rnd.uniform(0.2, 1.1)
        reeds.append([round(pond["x"] + math.cos(a) * rr, 2), round(pond["z"] + math.sin(a) * rr, 2), round(rnd.uniform(0.8, 1.3), 2)])
    tufts = []
    while len(tufts) < 900:
        x, z = rnd.uniform(-68, 68), rnd.uniform(-68, 68)
        if free(x, z, -3):
            tufts.append([round(x, 2), round(z, 2), round(rnd.uniform(0.6, 1.5), 2), round(rnd.uniform(0, 3.14), 2)])
    clouds = [[round(rnd.uniform(-90, 90)), round(rnd.uniform(34, 52)), round(rnd.uniform(-90, 90)), round(rnd.uniform(1.4, 2.8), 1)] for _ in range(12)]
    return dict(
        bushes=bushes, reeds=reeds, tufts=tufts, clouds=clouds,
        W=W, pen=pen, pond=pond, bog=bog, cliff=cliff, hut=hut_, market=market_, trough=trough_,
        trees=[t[:5] for t in trees], rocks=rocks, flags=flags, flowers=flowers, patches=patches, fences=fences,
    )


def main():
    world = gen_world()
    tpl = (HERE / "template.html").read_text(encoding="utf-8")
    html = tpl.replace("/*__MODELS__*/null", json.dumps(MODELS, separators=(",", ":")))
    html = html.replace("/*__WORLD__*/null", json.dumps(world, separators=(",", ":")))
    ART = {"merchant": merchant_svg(), "shepherd": shepherd_svg()}
    html = html.replace("/*__ART__*/null", json.dumps(ART, ensure_ascii=False))
    (HERE / "merchant.svg").write_text(ART["merchant"], encoding="utf-8")
    (HERE / "shepherd.svg").write_text(ART["shepherd"], encoding="utf-8")
    OUT.write_text(html, encoding="utf-8")
    (HERE / "models.json").write_text(json.dumps(MODELS, indent=1), encoding="utf-8")
    nparts = sum(len(v) for v in MODELS.values())
    print(f"✔ {len(MODELS)} مدل ({nparts} قطعه) | {len(world['trees'])} درخت | {len(world['rocks'])} سنگ")
    print(f"✔ ساخته شد: {OUT.name} ({OUT.stat().st_size // 1024} KB)")


if __name__ == "__main__":
    main()
