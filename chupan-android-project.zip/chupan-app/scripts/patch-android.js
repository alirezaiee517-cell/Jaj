// تنظیمات اندروید: حالت افقی، تمام‌صفحه و پشتیبانی از ناچ.
const fs = require('fs');
const path = require('path');

const app = path.join(__dirname, '..', 'android', 'app', 'src', 'main');
const manifestPath = path.join(app, 'AndroidManifest.xml');
let m = fs.readFileSync(manifestPath, 'utf8');
if (!m.includes('screenOrientation')) {
  m = m.replace('<activity', '<activity\n            android:screenOrientation="sensorLandscape"\n            android:hardwareAccelerated="true"');
  fs.writeFileSync(manifestPath, m);
  console.log('AndroidManifest: حالت افقی فعال شد');
}

const stylesPath = path.join(app, 'res', 'values', 'styles.xml');
let s = fs.readFileSync(stylesPath, 'utf8');
if (!s.includes('windowFullscreen')) {
  s = s.replace(/(<style name="AppTheme\.NoActionBar"[^>]*>)/,
    '$1\n        <item name="android:windowFullscreen">true</item>\n        <item name="android:windowLayoutInDisplayCutoutMode">shortEdges</item>');
  fs.writeFileSync(stylesPath, s);
  console.log('styles.xml: تمام‌صفحه و ناچ تنظیم شد');
}
